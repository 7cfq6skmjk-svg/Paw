<?php
require __DIR__.'/../server/db_connect.php';
$pdo=db_connect();
if($pdo instanceof PDO){
  echo 'Connection successful';
}else{
  $msg=function_exists('db_last_error')?db_last_error():'';
  if(isset($_GET['debug'])){
    $ext=extension_loaded('pdo_mysql')?'yes':'no';
    echo 'Connection failed: '.($msg?:'')."\n".'pdo_mysql loaded: '.$ext;
  }else{
    echo 'Connection failed'.($msg?': '.$msg:'');
  }
}
