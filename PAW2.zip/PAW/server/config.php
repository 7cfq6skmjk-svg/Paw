<?php
return [
  'host'=>'localhost',
  'username'=>'root',
  'password'=>'',
  'database'=>'attendance_db',
  'charset'=>'utf8mb4'
];
